-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 19-Mar-2024 às 11:28
-- Versão do servidor: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inscricoes`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `curso`
--

CREATE TABLE `curso` (
  `primeira_op` enum('CC','CP','EA','EI','ER','ET','IG','II','MC','ME','MF','MM','MT','MV','QA','QB','QI','QP','QT') DEFAULT NULL,
  `segunda_op` enum('CC','CP','EA','EI','ER','ET','IG','II','MC','ME','MF','MM','MT','MV','QA','QB','QI','QP','QT') DEFAULT NULL,
  `id_curso` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `curso`
--

INSERT INTO `curso` (`primeira_op`, `segunda_op`, `id_curso`) VALUES
('II', 'IG', 1),
('II', 'IG', 2),
('CC', 'CP', 3),
('II', 'IG', 4),
('IG', 'CC', 5),
('CC', 'IG', 6),
('ER', 'QT', 7),
('II', 'IG', 8),
('CP', 'CP', 9),
('EI', 'EI', 10),
('MF', 'ME', 17),
('MT', 'QA', 16),
('II', 'IG', 15);

-- --------------------------------------------------------

--
-- Estrutura da tabela `incricoes_aluno`
--

CREATE TABLE `incricoes_aluno` (
  `BI_aluno` varchar(15) NOT NULL,
  `Nome_Aluno` varchar(50) NOT NULL,
  `Data_Nascimento` date NOT NULL,
  `contacto_aluno` int(9) NOT NULL,
  `sexo_aluno` enum('M','F') NOT NULL,
  `Media` int(2) NOT NULL,
  `BI_Encarregado` varchar(14) NOT NULL,
  `nome_encarregado` varchar(50) NOT NULL,
  `id_curso` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `incricoes_aluno`
--

INSERT INTO `incricoes_aluno` (`BI_aluno`, `Nome_Aluno`, `Data_Nascimento`, `contacto_aluno`, `sexo_aluno`, `Media`, `BI_Encarregado`, `nome_encarregado`, `id_curso`) VALUES
('0074763836LA876', 'Deivi Dinis', '2006-03-08', 12345, 'M', 14, '23456789', '', 1),
('234567', 'Guilherme Bernardo', '2000-03-03', 123456, 'M', 14, '456789876', 'GUIl', 2),
('007465474LA654', 'ARTUR MACUMBA PAULO', '2000-07-25', 929277043, 'M', 15, '0097468464LA76', 'NDOMBELE PAULO', 3),
('0084758784LA75', 'FAbiola MAteus', '2006-02-19', 973683363, 'F', 15, '0083987LA877', 'MAteus', 4),
('009886686LA087', 'Rui Dala ', '2005-04-01', 948939589, 'M', 19, '006494649LA649', 'Venâncio Dala', 5),
('00675798LA543', 'Mariel Torres', '2007-08-26', 986856478, 'M', 16, '009753863LA765', 'Mariel', 6),
('007847894LA543', 'ANABELA PEDRO', '2007-04-13', 958938939, 'F', 15, '005463471LA456', 'TERESA PEDRO', 7),
('008946903LA044', 'WALDIR CAETANO', '2006-07-24', 933562681, 'M', 14, '008946903LA055', 'ANA CAETANO', 8),
('003456487LA907', 'RONALDO BERNARDO', '2005-06-30', 994789486, 'M', 16, '006478464LA645', 'CRISTIANO', 9),
('00635373LA879', 'STELVIO JOÃO CARIQUE', '2008-02-08', 965387343, 'M', 13, '00635376LA670', 'JOÃO CARIQUE', 10),
('00987654LA987', 'MANUEL FERREIRA', '2006-08-05', 987654321, 'M', 12, '00987654LA008', 'FERREIRA', 15),
('00987657LA534', 'EVANDER ANASTÁCIO ', '2003-09-26', 976357576, 'M', 11, '00986757LA533', 'ANASTÁCIO ', 16),
('004572345LA456', 'HERCULANO HEBO', '2007-08-05', 987653456, 'M', 16, '0098745757LA57', 'HEBO', 17);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `curso`
--
ALTER TABLE `curso`
  ADD PRIMARY KEY (`id_curso`);

--
-- Indexes for table `incricoes_aluno`
--
ALTER TABLE `incricoes_aluno`
  ADD PRIMARY KEY (`BI_aluno`),
  ADD UNIQUE KEY `id_curso` (`id_curso`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `curso`
--
ALTER TABLE `curso`
  MODIFY `id_curso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `incricoes_aluno`
--
ALTER TABLE `incricoes_aluno`
  MODIFY `id_curso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
