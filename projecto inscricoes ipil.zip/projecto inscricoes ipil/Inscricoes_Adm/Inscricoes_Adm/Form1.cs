﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inscricoes_Adm
{
    public partial class Form1 : Form
    {
        conexao conect=new conexao();
        MySqlCommand cmd;
        MySqlCommand cmd2;
        MySqlDataAdapter adapter;
        DataTable dt;
        public Form1()
        {
            InitializeComponent();
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
           string procura3= textBox1.Text;
           
            procurar3(procura3);
           
        }
        
        public void procurar3(string procurar3)
        {

            string query = "Select  BI_aluno,Nome_aluno,sexo_aluno,Media,nome_encarregado,primeira_op,segunda_op from incricoes_aluno inner join curso on incricoes_aluno.id_curso=curso.id_curso where concat(primeira_op,segunda_op,Nome_Aluno,BI_aluno,Media ) like'%" + procurar3 + "%' order by Nome_Aluno asc";
            cmd = new MySqlCommand(query, conect.abrirconexao());
            adapter = new MySqlDataAdapter(cmd);
            dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        public void procurar2(string procurar2)
        {

            string query = "Select  BI_aluno,Nome_aluno,sexo_aluno,Media,nome_encarregado,primeira_op,segunda_op from incricoes_aluno inner join curso on incricoes_aluno.id_curso=curso.id_curso where sexo_aluno like'%" + procurar2 + "%' order by Nome_Aluno asc";
            cmd = new MySqlCommand(query, conect.abrirconexao());
            adapter = new MySqlDataAdapter(cmd);
            dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            procurar3("");
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            conexao conect = new conexao();

            try
            {
                MySqlDataAdapter adp = new MySqlDataAdapter("Select  BI_aluno,Nome_aluno,Data_NAscimento,contacto_aluno,sexo_aluno,Media,nome_encarregado,primeira_op,segunda_op from incricoes_aluno inner join curso on incricoes_aluno.id_curso=curso.id_curso order by Nome_Aluno asc", conect.abrirconexao());
                DataTable tabela = new DataTable();

                adp.Fill(tabela);
                dataGridView1.DataSource = tabela;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }
            finally
            {
                conect.fecharconexao();
            }
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            editar editar = new editar();
            editar.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string query2 = "Select  BI_aluno,Nome_aluno,sexo_aluno,primeira_op from incricoes_aluno inner join curso on incricoes_aluno.id_curso=curso.id_curso where Media in(16,17,18,19,20) order by Nome_Aluno asc";
            cmd = new MySqlCommand(query2, conect.abrirconexao());
            adapter = new MySqlDataAdapter(cmd);
            dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string query = "Select  BI_aluno,Nome_aluno,sexo_aluno,segunda_op from incricoes_aluno inner join curso on incricoes_aluno.id_curso=curso.id_curso where Media in(13,14,15) order by Nome_Aluno asc";
            cmd = new MySqlCommand(query, conect.abrirconexao());
            adapter = new MySqlDataAdapter(cmd);
            dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string query = "Select  BI_aluno,Nome_aluno,sexo_aluno,primeira_op,segunda_op from incricoes_aluno inner join curso on incricoes_aluno.id_curso=curso.id_curso where Media <13 order by Nome_Aluno asc";
            cmd = new MySqlCommand(query, conect.abrirconexao());
            adapter = new MySqlDataAdapter(cmd);
            dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string procura2=textBox2.Text;
            procurar2(procura2);
        }
    }
}
