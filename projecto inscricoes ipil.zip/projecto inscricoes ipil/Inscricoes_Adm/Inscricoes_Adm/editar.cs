﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace Inscricoes_Adm
{
    public partial class editar : Form
    {
        public editar()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Nome_Aluno=textBox1.Text.ToUpper();
            string BI_aluno=textBox2.Text.ToUpper();  
            edita edita=new edita(BI_aluno,Nome_Aluno);
            MessageBox.Show("Nome editado com sucesso!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string nome_encarregado = textBox3.Text.ToUpper();
            string BI_aluno = textBox4.Text.ToUpper();
            editarencarregado edita = new editarencarregado(BI_aluno, nome_encarregado);
            MessageBox.Show("Nome do encarregado editado com sucesso!");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string sexo_aluno = textBox5.Text.ToUpper();
            string BI_aluno = textBox6.Text.ToUpper();
            editarsexo edita = new editarsexo(BI_aluno, sexo_aluno);
            MessageBox.Show("Sexo editado com sucesso!");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }
    }
}
