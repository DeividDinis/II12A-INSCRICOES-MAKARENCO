﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace Inscricoes_Adm
{
    internal class edita
    {
        conexao Conect = new conexao();
        MySqlCommand cmd = new MySqlCommand();
        public edita(string BI_aluno, string Nome_Aluno)
        {
            

            try
            {
                cmd.CommandText = "update incricoes_aluno set Nome_Aluno =@Nome_Aluno where BI_aluno=@BI_aluno";
                cmd.Parameters.AddWithValue("@Nome_Aluno", Nome_Aluno);
                cmd.Parameters.AddWithValue("@BI_aluno", BI_aluno);
                cmd.Connection = Conect.abrirconexao();
                cmd.ExecuteNonQuery();
                Conect.fecharconexao();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
      
    }
}
