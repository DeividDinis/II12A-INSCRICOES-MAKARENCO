﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
namespace Inscricoes_Adm
{
    internal class conexao
    {
        MySqlConnection conectar = new MySqlConnection();

        public conexao()
        {

            conectar.ConnectionString = "server=localhost;user=root;password='';database=inscricoes;Sslmode=none";
        }
        public MySqlConnection abrirconexao()
        {
            if (conectar.State == System.Data.ConnectionState.Closed)
            {
                conectar.Open();

            }
            return conectar;
        }
        public MySqlConnection fecharconexao()
        {
            if (conectar.State == System.Data.ConnectionState.Open)
            {
                conectar.Close();

            }
            return conectar;

        }
    }
}
