﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inscricoes_Adm
{
    internal class editarencarregado
    {
        conexao Conect = new conexao();
        MySqlCommand cmd = new MySqlCommand();
        public editarencarregado(string BI_aluno, string nome_encarregado)
        {


            try
            {
                cmd.CommandText = "update incricoes_aluno set nome_encarregado =@nome_encarregado where BI_aluno=@BI_aluno";
                cmd.Parameters.AddWithValue("@nome_encarregado", nome_encarregado);
                cmd.Parameters.AddWithValue("@BI_aluno", BI_aluno);
                cmd.Connection = Conect.abrirconexao();
                cmd.ExecuteNonQuery();
                Conect.fecharconexao();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
