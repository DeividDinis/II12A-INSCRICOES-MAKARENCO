﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace INSCRIÇÕES_IPIL
{
    internal class inscrever
    {
        conexao conect = new conexao();
        MySqlCommand comando2 = new MySqlCommand();
        public inscrever(string BI_aluno, string Nome_aluno, DateTime Data_Nascimento, int contacto_aluno, string sexo_aluno,int Media,string BI_Encarregado,string encarregado)
        {
            try
            {
                comando2.CommandText = "insert into incricoes_aluno values(@BI_aluno,@Nome_aluno,@Data_Nascimento,@contacto_aluno,@sexo_aluno,@Media,@BI_Encarregado,@encarregado,default)";
                comando2.Parameters.AddWithValue("@BI_aluno", BI_aluno);
                comando2.Parameters.AddWithValue("@Nome_aluno", Nome_aluno);
                comando2.Parameters.AddWithValue("@contacto_aluno", contacto_aluno);
                comando2.Parameters.AddWithValue("@Data_Nascimento",Data_Nascimento);
                comando2.Parameters.AddWithValue("@sexo_aluno", sexo_aluno);
                comando2.Parameters.AddWithValue("@Media", Media);
                comando2.Parameters.AddWithValue("@BI_Encarregado", BI_Encarregado);
                comando2.Parameters.AddWithValue("@encarregado", encarregado);

                comando2.Connection = conect.abrirconexao();
                comando2.ExecuteNonQuery();
                conect.fecharconexao();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro!" + ex.Message);
            }
        }
    }

  
}
