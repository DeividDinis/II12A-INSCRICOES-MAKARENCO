﻿namespace INSCRIÇÕES_IPIL
{
    partial class inscrições
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtnomeCompleto = new System.Windows.Forms.TextBox();
            this.txtTelefone = new System.Windows.Forms.TextBox();
            this.txtDAta = new System.Windows.Forms.TextBox();
            this.txtBIaluno = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.chckM = new System.Windows.Forms.CheckBox();
            this.chckF = new System.Windows.Forms.CheckBox();
            this.txtMedia = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.splitter2 = new System.Windows.Forms.Splitter();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.button1 = new System.Windows.Forms.Button();
            this.txtBIuser = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtencarregado = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtnomeCompleto
            // 
            this.txtnomeCompleto.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.txtnomeCompleto.Location = new System.Drawing.Point(245, 39);
            this.txtnomeCompleto.MaxLength = 50;
            this.txtnomeCompleto.Name = "txtnomeCompleto";
            this.txtnomeCompleto.Size = new System.Drawing.Size(391, 45);
            this.txtnomeCompleto.TabIndex = 0;
            this.txtnomeCompleto.TextChanged += new System.EventHandler(this.txtnomeCompleto_TextChanged);
            // 
            // txtTelefone
            // 
            this.txtTelefone.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.txtTelefone.Location = new System.Drawing.Point(247, 320);
            this.txtTelefone.MaxLength = 9;
            this.txtTelefone.Name = "txtTelefone";
            this.txtTelefone.Size = new System.Drawing.Size(253, 45);
            this.txtTelefone.TabIndex = 3;
            this.txtTelefone.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // txtDAta
            // 
            this.txtDAta.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.txtDAta.Location = new System.Drawing.Point(290, 232);
            this.txtDAta.MaxLength = 10;
            this.txtDAta.Name = "txtDAta";
            this.txtDAta.Size = new System.Drawing.Size(194, 45);
            this.txtDAta.TabIndex = 4;
            this.txtDAta.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // txtBIaluno
            // 
            this.txtBIaluno.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.txtBIaluno.Location = new System.Drawing.Point(244, 115);
            this.txtBIaluno.MaxLength = 14;
            this.txtBIaluno.Name = "txtBIaluno";
            this.txtBIaluno.Size = new System.Drawing.Size(391, 45);
            this.txtBIaluno.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(244, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 16);
            this.label1.TabIndex = 8;
            this.label1.Text = "Nome Completo*";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(244, 189);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(135, 16);
            this.label2.TabIndex = 9;
            this.label2.Text = "Data de Nascimento*";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(244, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 16);
            this.label3.TabIndex = 10;
            this.label3.Text = "Numero do BI*";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(244, 292);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 16);
            this.label4.TabIndex = 11;
            this.label4.Text = "Telefone principal*";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(287, 213);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 16);
            this.label5.TabIndex = 12;
            this.label5.Text = "YYYY-MM-DD";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(639, 211);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(38, 16);
            this.label8.TabIndex = 17;
            this.label8.Text = "Sexo";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // chckM
            // 
            this.chckM.AutoSize = true;
            this.chckM.Location = new System.Drawing.Point(569, 230);
            this.chckM.Name = "chckM";
            this.chckM.Size = new System.Drawing.Size(90, 20);
            this.chckM.TabIndex = 18;
            this.chckM.Text = "Masculino";
            this.chckM.UseVisualStyleBackColor = true;
            this.chckM.CheckedChanged += new System.EventHandler(this.chckM_CheckedChanged);
            // 
            // chckF
            // 
            this.chckF.AutoSize = true;
            this.chckF.Location = new System.Drawing.Point(670, 230);
            this.chckF.Name = "chckF";
            this.chckF.Size = new System.Drawing.Size(89, 20);
            this.chckF.TabIndex = 19;
            this.chckF.Text = "Femenino";
            this.chckF.UseVisualStyleBackColor = true;
            this.chckF.CheckedChanged += new System.EventHandler(this.chckF_CheckedChanged);
            // 
            // txtMedia
            // 
            this.txtMedia.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.txtMedia.Location = new System.Drawing.Point(247, 415);
            this.txtMedia.MaxLength = 2;
            this.txtMedia.Name = "txtMedia";
            this.txtMedia.Size = new System.Drawing.Size(63, 45);
            this.txtMedia.TabIndex = 20;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(244, 387);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(177, 16);
            this.label9.TabIndex = 21;
            this.label9.Text = "Media do insino secundario*";
            // 
            // splitter2
            // 
            this.splitter2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(137)))), ((int)(((byte)(33)))));
            this.splitter2.Location = new System.Drawing.Point(3, 0);
            this.splitter2.Name = "splitter2";
            this.splitter2.Size = new System.Drawing.Size(217, 639);
            this.splitter2.TabIndex = 23;
            this.splitter2.TabStop = false;
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 639);
            this.splitter1.TabIndex = 22;
            this.splitter1.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(137)))), ((int)(((byte)(33)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.button1.Location = new System.Drawing.Point(896, 573);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(174, 54);
            this.button1.TabIndex = 25;
            this.button1.Text = "Próximo";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtBIuser
            // 
            this.txtBIuser.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.txtBIuser.Location = new System.Drawing.Point(244, 482);
            this.txtBIuser.MaxLength = 14;
            this.txtBIuser.Name = "txtBIuser";
            this.txtBIuser.Size = new System.Drawing.Size(391, 45);
            this.txtBIuser.TabIndex = 26;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(242, 463);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(189, 16);
            this.label10.TabIndex = 27;
            this.label10.Text = "Numero do BI do encarregado";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(667, 20);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(150, 16);
            this.label11.TabIndex = 35;
            this.label11.Text = "Nome do Encarregado*";
            // 
            // txtencarregado
            // 
            this.txtencarregado.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.txtencarregado.Location = new System.Drawing.Point(670, 39);
            this.txtencarregado.MaxLength = 50;
            this.txtencarregado.Name = "txtencarregado";
            this.txtencarregado.Size = new System.Drawing.Size(391, 45);
            this.txtencarregado.TabIndex = 34;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::INSCRIÇÕES_IPIL.Properties.Resources.IPIL1;
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(148, 148);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 24;
            this.pictureBox1.TabStop = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(137)))), ((int)(((byte)(33)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.button2.Location = new System.Drawing.Point(290, 573);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(174, 54);
            this.button2.TabIndex = 36;
            this.button2.Text = "Retornar";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // inscrições
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1082, 639);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtencarregado);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtBIuser);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.splitter2);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtMedia);
            this.Controls.Add(this.chckF);
            this.Controls.Add(this.chckM);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtBIaluno);
            this.Controls.Add(this.txtDAta);
            this.Controls.Add(this.txtTelefone);
            this.Controls.Add(this.txtnomeCompleto);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "inscrições";
            this.Text = "m00l";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtnomeCompleto;
        private System.Windows.Forms.TextBox txtTelefone;
        private System.Windows.Forms.TextBox txtDAta;
        private System.Windows.Forms.TextBox txtBIaluno;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckBox chckM;
        private System.Windows.Forms.CheckBox chckF;
        private System.Windows.Forms.TextBox txtMedia;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Splitter splitter2;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtBIuser;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtencarregado;
        private System.Windows.Forms.Button button2;
    }
}