﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace INSCRIÇÕES_IPIL
{
    public partial class Admitidos : Form
    {
        conexao conect = new conexao();
        MySqlCommand cmd;
        MySqlCommand cmd2;
        MySqlDataAdapter adapter;
        DataTable dt;
        public Admitidos()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string procura = textBox2.Text;
            procurar(procura);
        }
        public void procurar(string procurar)
        {

            string query = "Select  BI_aluno,Nome_aluno,sexo_aluno,primeira_op,segunda_op from incricoes_aluno inner join curso on incricoes_aluno.id_curso=curso.id_curso where BI_aluno like'%" + procurar + "%' order by Nome_aluno asc";
            cmd = new MySqlCommand(query, conect.abrirconexao());
            adapter = new MySqlDataAdapter(cmd);
            dt = new DataTable();
            adapter.Fill(dt);
            dataGridView2.DataSource = dt;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query2 = "Select  BI_aluno,Nome_aluno,sexo_aluno,primeira_op from incricoes_aluno inner join curso on incricoes_aluno.id_curso=curso.id_curso where Media in(16,17,18,19,20)order by Nome_aluno asc";
            cmd = new MySqlCommand(query2, conect.abrirconexao());
            adapter = new MySqlDataAdapter(cmd);
            dt = new DataTable();
            adapter.Fill(dt);
            dataGridView2.DataSource = dt;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string query2 = "Select  BI_aluno,Nome_aluno,sexo_aluno,segunda_op from incricoes_aluno inner join curso on incricoes_aluno.id_curso=curso.id_curso where Media in(13,14,15) order by Nome_aluno asc";
            cmd = new MySqlCommand(query2, conect.abrirconexao());
            adapter = new MySqlDataAdapter(cmd);
            dt = new DataTable();
            adapter.Fill(dt);
            dataGridView2.DataSource = dt;
        }

        private void splitter2_SplitterMoved(object sender, SplitterEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Pagina_Inicial pagina_Inicial = new Pagina_Inicial();                       
            pagina_Inicial.Show();
            this.Hide();
        }
    }
}
