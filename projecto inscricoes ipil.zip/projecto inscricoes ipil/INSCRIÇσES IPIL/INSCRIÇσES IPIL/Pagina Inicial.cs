﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace INSCRIÇÕES_IPIL
{
    public partial class Pagina_Inicial : Form
    {
        public Pagina_Inicial()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            inscrições inscricoes = new inscrições();
            inscricoes.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
          Admitidos amd = new Admitidos();
            amd.Show();
            this.Hide();
               
        }
    }
}
