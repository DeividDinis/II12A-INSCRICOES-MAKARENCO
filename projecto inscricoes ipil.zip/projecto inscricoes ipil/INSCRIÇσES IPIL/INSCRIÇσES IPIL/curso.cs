﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace INSCRIÇÕES_IPIL
{
    internal class curso
    {
        conexao conect = new conexao();
        MySqlCommand comando3 = new MySqlCommand();
        public curso(string primeira_op, string segunda_op)
        {
            try
            {
                comando3.CommandText = "insert into curso values(@primeira_op,@segunda_op,default)";
                comando3.Parameters.AddWithValue("@primeira_op", primeira_op);
                comando3.Parameters.AddWithValue("@segunda_op", segunda_op);
                comando3.Connection = conect.abrirconexao();
                comando3.ExecuteNonQuery();
                conect.fecharconexao();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro!" + ex.Message);
            }
           
        }
    }
}
