﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace INSCRIÇÕES_IPIL
{
    public partial class inscrições : Form
    {
        public inscrições()
        {
            InitializeComponent();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string BI_Encarregado = txtBIuser.Text.ToUpper();
            string Nome_aluno = txtnomeCompleto.Text.ToUpper();
            string contacto_aluno = txtTelefone.Text;
            string BI_aluno = txtBIaluno.Text.ToUpper();
            DateTime Data_Nascimento = DateTime.Parse(txtDAta.Text);
            int Media = int.Parse(txtMedia.Text);
            string encarregado=txtencarregado.Text.ToUpper();

            string sexo_aluno;
            if ((chckM.Checked == true) && (chckF.Checked == false)&&(BI_aluno.Length==14)&&(BI_Encarregado.Length==14)&&(contacto_aluno.Length==9))
            {
                
                int contacto_alun = int.Parse(contacto_aluno);
                sexo_aluno = "M";
                inscrever cad = new inscrever(BI_aluno, Nome_aluno, Data_Nascimento, contacto_alun, sexo_aluno, Media, BI_Encarregado,encarregado);
                Cursos cou = new Cursos();
                cou.Show();
                this.Hide();

            }  else if ((Media<10)||(Media>20))
            {
                MessageBox.Show("Erro! na média do aluno");
            }
            else if ((BI_aluno.Length == 14) && (BI_Encarregado.Length == 14) && (contacto_aluno.Length == 9))
            {
                int contacto_alun = int.Parse(contacto_aluno);
                sexo_aluno = "F";
                inscrever cad = new inscrever(BI_aluno, Nome_aluno, Data_Nascimento, contacto_alun, sexo_aluno, Media, BI_Encarregado, encarregado);
                Cursos cou = new Cursos();
                cou.Show();
                this.Hide();
            }else if (BI_Encarregado==" ")
            {
                MessageBox.Show("Preencha o campo do BI do encarregado!");
            }
            else if (BI_aluno == " ")
            {
                MessageBox.Show("Preencha o campo do BI do aluno!");
            }
            else if (Nome_aluno == " ")
            {
                MessageBox.Show("Preencha o campo do nome do aluno!");
            }
            else if (contacto_aluno == " ")
            {
                MessageBox.Show("Preencha o campo do contacto aluno!");
            }
            else if (encarregado == " ")
            {
                MessageBox.Show("Preencha o campo do nome do encarregado!");
            }
            
            else if (BI_aluno.Length < 14)
            {
                MessageBox.Show("Faltam alguns digitos no BI do aluno");
            }
            else if (BI_Encarregado.Length < 14)
            {
                MessageBox.Show("Faltam alguns digitos no BI do encarregado");
            }
          
            else if(contacto_aluno.Length != 9)
            {
                MessageBox.Show("Número Errado!");
            }

            else
            {
                MessageBox.Show("Verifique se preencheu corretamente todos os campos!");
            }

           
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void txtnomeCompleto_TextChanged(object sender, EventArgs e)
        {
          // txtnomeCompleto.Text = txtnomeCompleto.Text.ToUpper();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Pagina_Inicial pagina_Inicial = new Pagina_Inicial();
            pagina_Inicial.Show();
            this.Hide();
        }

        private void chckM_CheckedChanged(object sender, EventArgs e)
        {
            if (chckM.Checked==true)
            {
                chckF.Enabled = false;
            }
            else
            {
                chckF.Enabled = true;
            }
            
        }

        private void chckF_CheckedChanged(object sender, EventArgs e)
        {
            if (chckF.Checked == true)
            {
                chckM.Enabled = false;
            }
            else
            {
                chckM.Enabled = true;
            }
        }
    }
}
