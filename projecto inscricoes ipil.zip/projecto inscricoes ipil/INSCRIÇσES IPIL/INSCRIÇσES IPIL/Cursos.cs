﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace INSCRIÇÕES_IPIL
{
    public partial class Cursos : Form
    { 
        public Cursos()
        {
            InitializeComponent();
        }

        private void Cursos_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string primeira_op = txtprimeiro.Text.ToUpper();
            string segundo_op = txtsegundo.Text.ToUpper();
            curso cd = new curso(primeira_op, segundo_op);
            inscrições inscrições= new inscrições();
            inscrições.Show();
            this.Hide();
             if ((primeira_op != "CC") && (primeira_op != "CP") && (primeira_op != "EA") && (primeira_op != "EI") && (primeira_op != "ER") &&
                (primeira_op != "ET") && (primeira_op != "IG") && (primeira_op != "II") && (primeira_op != "MC") && (primeira_op != "ME") && (primeira_op != "MF") &&
                (primeira_op != "MM") && (primeira_op != "MT") && (primeira_op != "MV") && (primeira_op != "QA") && (primeira_op != "QB") && (primeira_op != "QI") && (primeira_op != "QP") &&
                (primeira_op != "QT") && (segundo_op != "CC") && (segundo_op != "CP") && (segundo_op != "EA") && (segundo_op != "EI") && (segundo_op != "ER") &&
                (segundo_op != "ET") && (segundo_op != "IG") && (segundo_op != "II") && (segundo_op != "MC") && (segundo_op != "ME") && (segundo_op != "MF") &&
                (segundo_op != "MM") && (segundo_op != "MT") && (segundo_op != "MV") && (segundo_op != "QA") && (segundo_op != "QB") && (segundo_op != "QI") && (segundo_op != "QP") &&
                (segundo_op != "QT"))
            {
                MessageBox.Show("Verifique se preencheu corretamente o código do curso pretendido");
            }else if (primeira_op == segundo_op)
            {
                MessageBox.Show("A primeira Opção não pode ser igual a segunda Opção");
            }
            else
            {
                MessageBox.Show("Inscrito com Sucesso!");
            }
        }
    }
}
